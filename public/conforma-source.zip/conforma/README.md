# Conforma

**A protein workspace you can take with you.**

[![Conforma — a real molecular structure rendered in its interactive editorial cover](docs/protein-workspace.png)](https://rp-conforma.vercel.app)

**[Open the experience](https://rp-conforma.vercel.app)** · **[Methods & credits](https://rp-conforma.vercel.app/methods.html)** · **[Download & run locally](https://rp-conforma.vercel.app/conforma-source.zip)**

Search public protein structures, open your own PDB/mmCIF file, or construct geometry from an amino acid sequence. Inspect chains, measure atom distances, export a figure or modeled FASTA, and save a workspace you can reopen on another device. No account is required. Local files and sequence construction stay in your browser.

**New in 1.2:** the workspace is the homepage. Saved version 2 records include coordinate text, a SHA-256 integrity check, view settings and, for constructed models, a recipe that must reproduce the saved coordinates before reopening. Saved source labels are not treated as authenticated provenance. Older version 1 records remain readable JSON but cannot be reopened by this importer.

## Why I’m building it

I’m a chemical biology student at UC Berkeley. I want the software I build to make biology easier to work with: let someone bring their own question, inspect the underlying coordinates, and leave with work they can reuse. That means keeping private files local, preserving portable records, and explaining the difference between an observed structure and a constructed model. [The story](https://rp-conforma.vercel.app/#why).

The original [two-structure adenylate kinase study](https://rp-conforma.vercel.app/study.html) remains available, including its independently checked alignment engine.

## Your own protein workspace

![Conforma protein workspace with a real multichain structure](docs/protein-workspace.png)

**[Open a protein or construct a sequence](https://rp-conforma.vercel.app/)**

- Search RCSB PDB by protein name or load a classic/extended PDB ID. Downloads use mmCIF, so multicharacter chain IDs are supported.
- Open local uncompressed PDB/mmCIF files in a parser worker. Files stay on the device. View chains individually or together, switch between atoms and Cα traces, change colors, inspect atoms and measure distances.
- Download the original coordinate file without modifying its bytes, or export a record containing source hashes, selected-view settings and parsed coordinates. Coordinate-derived FASTA exports explicitly omit missing residues.
- Type 3–500 standard amino acids or one FASTA record to construct a local model. Choose α-helical, extended, or custom φ/ψ torsions. Optional residue-specific side chains use bundled RCSB CCD **ideal component** coordinates fitted onto N/CA/C anchors.
- Download constructed PDB coordinates with explicit non-prediction remarks. The builder uses no external prediction service and sends no sequence to RCSB.

**Construction is not folding.** The shape follows your chosen backbone torsions and reference side-chain templates, rather than predicting a sequence-specific native state. Side-chain rotamers, ring closure, steric clashes, terminal caps, protonation, hydrogens and residue-specific torsion preferences are not validated or optimized. Template anchor-fit RMSDs are retained in the record.

Limits: 12 MiB uncompressed text, 100,000 parsed protein atoms, 24,000 displayed atoms at once. Large entries may require choosing one chain. First model/data block and blank/A alternates are used. Water, ligands and nucleic acids are omitted; biological assemblies are not expanded. This supports many ordinary protein structures, not every archive format or arbitrarily large assembly. RCSB name searches and structure retrieval contact the official public services only after the relevant user action; local files and sequence construction stay local.

## What you can do in the original study

- Rotate **1,656 common heavy atoms** or switch to a smooth Cα backbone view.
- Inspect both observed endpoints and a clearly labeled illustrative geometric blend.
- Highlight the core, NMP region or lid; compare their Cα displacements after alignment.
- Switch between core-only and whole-chain fitting to see alignment sensitivity.
- Select residues in 3D or enter their numbers to measure endpoint distances.
- Export a labeled PNG or a full study JSON with matched coordinates, source hashes, fit settings and measurements.
- Keep using endpoint analysis when WebGL is unavailable; the fallback clearly identifies its static open-state projection.

The visual direction is an editorial specimen gallery: original identity, self-hosted typography, restrained color, and a real molecular form as the cover. There are no external runtime scripts, tracking SDKs, user accounts, paid AI APIs, or generated molecular stock images. The protein workspace makes explicit read-only requests to RCSB for searches/downloads; local coordinate parsing and sequence construction stay in-browser. See [the design notes](docs/design.md).

## Run locally

Node.js 22+:

```sh
npm ci
npm run build
npm start
# http://127.0.0.1:4472
```

The download includes the built `public/` site. To use it without installing packages, run `node server.mjs`. The server binds to loopback and serves only static files; there is no hosted analysis API. The scientific module and CLI use only Node built-ins.

```sh
node cli.mjs compare --fit core --out report.json
node cli.mjs compare --fit all --out whole-chain.json
node cli.mjs measure 55 150
```

## Reuse the scientific engine

```js
import {readFile} from 'node:fs/promises';
import {parsePDB, compareStructures, measurePair} from './src/science.mjs';

const open = parsePDB(await readFile('public/data/4AKE.pdb', 'utf8'));
const closed = parsePDB(await readFile('public/data/1AKE.pdb', 'utf8'));
const report = compareStructures(open, closed, {fit: 'core'});
console.log(report.fit_rmsd, report.domains.LID.rmsd);
console.log(measurePair(report, 55, 150));
```

## Method and reproducibility

A Horn quaternion fit rigidly aligns the closed structure to the open structure, using either 133 core Cα atoms or all 214 matched Cα atoms. A Jacobi eigensolver finds the optimal proper rotation. Atom correspondence requires identical residue numbers, insertion codes, atom names, and residue identities; there is no general sequence alignment or invented completion of missing atoms.

The declared [domain convention](https://doi.org/10.1371/journal.pcbi.1003938) is CORE 1–29, 68–117, 161–214; NMP 30–67; LID 118–160. Other literature uses different boundaries. Domain RMSD is measured after the selected reference fit, not independently minimized for each domain.

With the bundled records, core-fit RMSD is **1.5508 Å**, all-chain Cα RMSD after that core fit is **8.0940 Å**, and lid-domain RMSD is **14.8687 Å**. Whole-chain fitting gives **7.1307 Å** for its own fit. The ruler between residues 55 and 150 reports **43.6249 Å** open and **30.9013 Å** closed. Units and conventions belong with these values.

Raw PDB files, retrieval timestamps, source URLs and SHA-256 hashes are bundled. `npm run data` refreshes them from RCSB and regenerates the reference comparison; review the changed hashes and rerun checks before publishing refreshed data. This is a pinned snapshot, not a live structural-data service.

## Checks actually executed

- `npm test`: source-file hashes and derived-coordinate agreement, known rigid transforms, proper rotations versus reflection, sparse/malformed coordinates, domain counts, correspondence exclusions, interpolation bounds and fit-invariant internal distances.
- An independent **NumPy SVD** implementation checked both real-structure fits and **30 seeded rigid transforms**. Maximum coordinate differences in those fixtures were below 10⁻⁸ Å. [Recorded results](docs/numpy-comparison.json).
- Browser workflow results, environments and limits are recorded in [docs/browser-results.json](docs/browser-results.json). Software WebGL and emulated phone checks are not physical-device validation.

Optional independent validation:

```sh
python3 -m venv .validation-env
.validation-env/bin/pip install -r scripts/requirements-validation.txt
.validation-env/bin/python scripts/compare-numpy.py
```

Browser development checks require a running preview and the test browser:

```sh
npx playwright install chromium
node tests/browser.mjs
# CONFORMA_URL can select a deployment.
# CONFORMA_BROWSER can select an installed Chromium executable.
```

## Protein workspace module / CLI

```sh
node cli.mjs inspect protein.cif --out parsed.json
node cli.mjs build ACDEFGHIKLMNPQRSTVWY --out idealized.pdb
node cli.mjs build AEAAAKEAAAKEAAAKA --phi -135 --psi 135 --backbone-only --out extended.pdb
```

`src/proteins.mjs` handles the supported coordinate formats; `src/sequence.mjs` builds the idealized backbone; `src/sidechains.mjs` applies the source-hashed CCD templates. `scripts/prepare-sidechains.mjs` refreshes those public templates; it never receives user sequences. The original `compare` and `measure` CLI commands remain specific to the bundled adenylate-kinase study.

The expanded checks cover PDB/mmCIF agreement on independently encoded crambin files, a real four-chain hemoglobin fixture, malformed input rejection, download/display bounds, FASTA validation, backbone bond lengths and torsions, all 20 CCD template hashes, side-chain identity and internal-distance preservation, and PDB round trips. See [protein browser results](docs/protein-browser-results.json) for live RCSB downloads/search, local file import, sequence privacy, exports, fallback and emulated-phone checks.

## Important interpretation limits

The slider linearly interpolates geometry. Intermediate frames are **not** a measured motion, a valid molecular-dynamics trajectory, a reaction mechanism, or a time-resolved experiment. No energy, force, rate or binding affinity is computed. Atomic bead sizes and colors are display choices, not a solvent-accessible surface. Water, ligands and unmatched atoms are omitted from the displayed model.

This is a curated comparison, not a replacement for Mol*, NGL, PyMOL, general structure alignment, structural validation, or molecular dynamics. Differences can reflect ligand state, crystal environment and experimental uncertainty. No worldwide novelty, clinical use, mechanistic discovery, or award is claimed.

## Project map

- `src/science.mjs` — zero-dependency parser, Horn fit, correspondence, RMSD, interpolation and ruler.
- `src/viewer.mjs` — custom instanced WebGL atomic display, backbone, overlay, picking and lifecycle handling.
- `src/app.mjs` — comparison controls, analysis displays and reproducible exports.
- `scripts/prepare-data.mjs` — fixed-source RCSB retrieval and provenance.
- `scripts/compare-numpy.py` — independent optional SVD checks.
- `public/` — self-contained built website, fonts and source coordinates.
- `tests/` — engine and browser verification.

MIT software by Rishit Pradhan. Structural data: original depositors and RCSB PDB / wwPDB; see [source records](public/data/structures.json). Font licenses are bundled. Design references and verification limits are documented rather than presented as endorsements.
